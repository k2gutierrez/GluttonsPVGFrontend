# Gluttons Reap Keeper v1.0

Permissionless accounting keeper for the canonical Gluttons `GameEngine.sol` v1.0.2 line.

## Why it exists

Glutton death is logical at the canonical timestamp even if nobody has yet sent a transaction. `getVisualState()` can therefore show FRESH/ROTTEN immediately, while `s_aliveCount` changes only when `_materializeLogicalDeath()` is executed. `reap()` is the permissionless batch entry point that materializes those deaths and advances global accounting.

The keeper is infrastructure only. **There must be no REAP button in the player UI.**

## Safety model

- Uses only the permissionless `GameEngine.reap(uint256[])` function.
- Keeper wallet has **no owner/admin role** and should hold only enough native gas token to operate.
- Never derives death using local wall-clock rules. It asks the GameEngine for canonical `getVisualState()` and checks `deathSettled`.
- Only FRESH/ROTTEN + `deathSettled == false` are submitted.
- `reap()` is idempotent: already-settled/alive IDs are harmless no-ops.
- Simulates every batch before broadcast.
- Estimates gas and recursively splits oversized/failing batches.
- If RPC/scanning fails, it sends nothing and retries later.
- A successful sweep can legitimately advance Plague/Last Supper thresholds or settle the zero-survivor tiebreak. That is canonical protocol behavior, not keeper discretion.

## Curtis setup

```bash
cp .env.example .env
```

Set:

```env
RPC_URL=https://curtis.rpc.caldera.xyz/http
CHAIN_ID=33111
GAME_ENGINE_ADDRESS=0xYOUR_CURRENT_ENGINE
KEEPER_PRIVATE_KEY=0xDEDICATED_HOT_WALLET_PRIVATE_KEY
CHAIN_NAME=ApeChain Curtis
NATIVE_SYMBOL=APE
SWEEP_INTERVAL_MS=15000
READ_BATCH_SIZE=100
REAP_BATCH_SIZE=20
MAX_GAS_PER_TX=2500000
DRY_RUN=true
```

Then:

```bash
npm install
npm run check
npm run run:once
```

Confirm the printed Engine, chain, keeper wallet, S/alive counts and candidates. Then change:

```env
DRY_RUN=false
```

and run one live sweep:

```bash
npm run run:once
```

Only after that succeeds, run continuously:

```bash
npm run dev
```

For a server:

```bash
npm run build
node dist/keeper.js
```

Use PM2/systemd/Docker or another supervised process so it restarts after failure/reboot.

## Mainnet recommended defaults

Do **not** copy Curtis timing blindly. Suggested starting values:

```env
SWEEP_INTERVAL_MS=120000
READ_BATCH_SIZE=100
REAP_BATCH_SIZE=20
MAX_GAS_PER_TX=2500000
CONFIRMATIONS=2
DRY_RUN=true
```

A two-minute sweep is usually fast enough for game accounting without creating unnecessary RPC load. Because the keeper sends transactions only when canonical unsettled deaths exist, idle sweeps cost RPC reads but no gas.

Before mainnet:

1. Use a paid/reliable RPC endpoint rather than a public community endpoint.
2. Use a dedicated keeper wallet, not owner/admin/deployer keys.
3. Fund it only with an operational gas budget.
4. Set provider spending/balance alerts.
5. Run DRY_RUN for at least one full Curtis game and compare `s_aliveCount` against the frontend Matrix.
6. Confirm every keeper transaction only calls the configured GameEngine address.
7. Back up `.env` securely; never commit it.

## How candidate detection works

For token IDs `1..S`, each sweep reads in deployless multicall batches:

- `getVisualState(tokenId)`
- `s_tokenStates(tokenId)`

Candidate condition:

```text
visualState == FRESH (2) or ROTTEN (3)
AND deathSettled == false
```

This correctly respects:

- normal starvation at logical expiry;
- FASTING surviving at 0H before Last Supper;
- FASTING at 0H dying at the Last Supper bell;
- Final Bite death at its deadline;
- already-devoured/consumed tokens being ignored because their accounting is already settled.

## Failure behavior

The keeper follows fail-closed behavior:

```text
RPC/read failure -> NO TX -> retry next sweep
candidate batch -> simulate -> estimate gas
oversized/failing batch -> recursively split
single-ID failure -> log + skip this sweep
```

The frontend should independently show `CHAIN ACCOUNTING CATCHING UP` when its logical Matrix count differs from `s_aliveCount`. The keeper should normally make that state short-lived.

## Foundry emergency fallback

`script/ReapRange.s.sol` is included only as an operational fallback. It reaps an ID range directly and therefore may spend gas checking live IDs.

Example:

```bash
GAME_ENGINE_ADDRESS=0x... \
KEEPER_PRIVATE_KEY=123456... \
START_ID=1 \
END_ID=100 \
BATCH_SIZE=20 \
forge script script/ReapRange.s.sol:ReapRange \
  --rpc-url "$RPC_URL" \
  --broadcast -vvv
```

Prefer the Node keeper for normal operation because it identifies candidates before sending transactions.

## Canonical relationship to frontend

Player UI:

```text
NO REAP BUTTON
```

Infrastructure:

```text
logical death -> frontend can show corpse immediately
              -> keeper materializes accounting
              -> s_aliveCount / phase thresholds catch up
```

Corpse actions (`KEEP FRESH`, Fresh/Rotten consumption) also auto-materialize their own target internally, so a player does not wait for this keeper to use a corpse.
