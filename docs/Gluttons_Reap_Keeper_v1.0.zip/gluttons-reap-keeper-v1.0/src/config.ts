import 'dotenv/config'
import { getAddress, type Address, type Hex } from 'viem'

function req(name: string): string {
  const value = process.env[name]
  if (!value) throw new Error(`Missing required environment variable: ${name}`)
  return value
}

function int(name: string, fallback: number): number {
  const raw = process.env[name]
  if (!raw) return fallback
  const value = Number(raw)
  if (!Number.isFinite(value) || value <= 0 || !Number.isInteger(value)) {
    throw new Error(`${name} must be a positive integer`)
  }
  return value
}

function bool(name: string, fallback: boolean): boolean {
  const raw = process.env[name]
  if (raw == null) return fallback
  return ['1', 'true', 'yes', 'on'].includes(raw.toLowerCase())
}

const pk = req('KEEPER_PRIVATE_KEY') as Hex
if (!/^0x[0-9a-fA-F]{64}$/.test(pk)) {
  throw new Error('KEEPER_PRIVATE_KEY must be a 32-byte 0x-prefixed private key')
}

export const cfg = {
  rpcUrl: req('RPC_URL'),
  chainId: int('CHAIN_ID', 33111),
  gameEngine: getAddress(req('GAME_ENGINE_ADDRESS')) as Address,
  privateKey: pk,
  sweepIntervalMs: int('SWEEP_INTERVAL_MS', 15_000),
  readBatchSize: int('READ_BATCH_SIZE', 100),
  reapBatchSize: int('REAP_BATCH_SIZE', 20),
  maxGasPerTx: BigInt(int('MAX_GAS_PER_TX', 2_500_000)),
  confirmations: int('CONFIRMATIONS', 1),
  dryRun: bool('DRY_RUN', true),
  runOnce: bool('RUN_ONCE', false),
  chainName: process.env.CHAIN_NAME || 'Gluttons Chain',
  nativeSymbol: process.env.NATIVE_SYMBOL || 'ETH'
}
