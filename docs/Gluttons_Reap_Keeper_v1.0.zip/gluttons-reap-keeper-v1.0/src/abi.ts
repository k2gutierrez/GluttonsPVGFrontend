import { parseAbi } from 'viem'

export const gameEngineAbi = parseAbi([
  'function S() view returns (uint256)',
  'function s_gameStart() view returns (uint64)',
  'function s_isSettled() view returns (bool)',
  'function s_aliveCount() view returns (uint256)',
  'function currentPhaseCode() view returns (uint8)',
  'function getVisualState(uint256 tokenId) view returns (uint8)',
  'function s_tokenStates(uint256 tokenId) view returns (uint64 expiry, uint64 poisonProtectedUntil, uint64 finalBiteDeadline, uint64 deadAt, uint64 spoilCheckpoint, uint64 poweredUntil, uint32 spoilQ4, bool fasting, bool deathSettled)',
  'function reap(uint256[] tokenIds)'
])
