// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import {Script, console2} from "forge-std/Script.sol";

interface IGameEngineReap {
    function reap(uint256[] calldata tokenIds) external;
    function S() external view returns (uint256);
    function s_aliveCount() external view returns (uint256);
    function s_isSettled() external view returns (bool);
}

/**
 * @notice Emergency/manual fallback only.
 * @dev The Node keeper is preferred because it only sends candidates.
 *      This script safely calls reap over a configured ID range; live IDs are no-ops.
 *
 * Env:
 * GAME_ENGINE_ADDRESS=0x...
 * KEEPER_PRIVATE_KEY=<uint private key>
 * START_ID=1
 * END_ID=100
 * BATCH_SIZE=20
 */
contract ReapRange is Script {
    function run() external {
        address engineAddress = vm.envAddress("GAME_ENGINE_ADDRESS");
        uint256 privateKey = vm.envUint("KEEPER_PRIVATE_KEY");
        uint256 startId = vm.envOr("START_ID", uint256(1));
        uint256 endId = vm.envOr("END_ID", IGameEngineReap(engineAddress).S());
        uint256 batchSize = vm.envOr("BATCH_SIZE", uint256(20));

        require(startId >= 1 && endId >= startId, "bad range");
        require(batchSize > 0, "bad batch size");

        IGameEngineReap engine = IGameEngineReap(engineAddress);
        console2.log("Alive before:", engine.s_aliveCount());

        vm.startBroadcast(privateKey);
        for (uint256 cursor = startId; cursor <= endId;) {
            uint256 last = cursor + batchSize - 1;
            if (last > endId) last = endId;
            uint256 len = last - cursor + 1;
            uint256[] memory tokenIds = new uint256[](len);
            for (uint256 i = 0; i < len; i++) tokenIds[i] = cursor + i;
            engine.reap(tokenIds);
            cursor = last + 1;
        }
        vm.stopBroadcast();

        console2.log("Alive after:", engine.s_aliveCount());
        console2.log("Settled:", engine.s_isSettled());
    }
}
