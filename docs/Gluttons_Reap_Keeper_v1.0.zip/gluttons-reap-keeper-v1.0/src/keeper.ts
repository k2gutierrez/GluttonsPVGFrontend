import {
  createPublicClient,
  createWalletClient,
  defineChain,
  http,
  formatEther,
  type Address
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { cfg } from './config.js'
import { gameEngineAbi } from './abi.js'

const chain = defineChain({
  id: cfg.chainId,
  name: cfg.chainName,
  nativeCurrency: { name: cfg.nativeSymbol, symbol: cfg.nativeSymbol, decimals: 18 },
  rpcUrls: { default: { http: [cfg.rpcUrl] } }
})

const account = privateKeyToAccount(cfg.privateKey)
const publicClient = createPublicClient({ chain, transport: http(cfg.rpcUrl, { retryCount: 3, retryDelay: 250 }) })
const walletClient = createWalletClient({ account, chain, transport: http(cfg.rpcUrl, { retryCount: 3, retryDelay: 250 }) })

const phaseNames = ['PRE_GAME', 'FEAST', 'PLAGUE', 'LS_WARNING', 'LAST_SUPPER', 'SETTLED'] as const
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))

function chunks<T>(items: T[], size: number): T[][] {
  const out: T[][] = []
  for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size))
  return out
}

function ids(from: bigint, to: bigint): bigint[] {
  const out: bigint[] = []
  for (let i = from; i <= to; i++) out.push(i)
  return out
}

async function readStatus() {
  const [gameStart, supply, settled, alive, phase] = await Promise.all([
    publicClient.readContract({ address: cfg.gameEngine, abi: gameEngineAbi, functionName: 's_gameStart' }),
    publicClient.readContract({ address: cfg.gameEngine, abi: gameEngineAbi, functionName: 'S' }),
    publicClient.readContract({ address: cfg.gameEngine, abi: gameEngineAbi, functionName: 's_isSettled' }),
    publicClient.readContract({ address: cfg.gameEngine, abi: gameEngineAbi, functionName: 's_aliveCount' }),
    publicClient.readContract({ address: cfg.gameEngine, abi: gameEngineAbi, functionName: 'currentPhaseCode' })
  ])
  return { gameStart, supply, settled, alive, phase: Number(phase) }
}

/**
 * A reap candidate is canonical logical death (visual state FRESH or ROTTEN)
 * whose accounting has not yet been materialized (deathSettled == false).
 *
 * We intentionally do NOT derive death from local time. GameEngine remains the
 * only source of truth, including FASTING-at-0 and FINAL BITE behavior.
 */
async function findCandidates(supply: bigint): Promise<bigint[]> {
  const allIds = ids(1n, supply)
  const candidates: bigint[] = []

  for (const group of chunks(allIds, cfg.readBatchSize)) {
    const contracts = group.flatMap(tokenId => ([
      {
        address: cfg.gameEngine,
        abi: gameEngineAbi,
        functionName: 'getVisualState' as const,
        args: [tokenId] as const
      },
      {
        address: cfg.gameEngine,
        abi: gameEngineAbi,
        functionName: 's_tokenStates' as const,
        args: [tokenId] as const
      }
    ]))

    // deployless=true is important for chains/testnets without Multicall3 deployed.
    const results = await publicClient.multicall({
      contracts,
      allowFailure: true,
      deployless: true,
      batchSize: 65_536
    })

    for (let i = 0; i < group.length; i++) {
      const visual = results[i * 2]
      const state = results[i * 2 + 1]
      if (visual.status !== 'success' || state.status !== 'success') continue

      const visualState = Number(visual.result)
      const tokenState = state.result as readonly [bigint, bigint, bigint, bigint, bigint, bigint, number, boolean, boolean]
      const deathSettled = Boolean(tokenState[8])

      if (!deathSettled && (visualState === 2 || visualState === 3)) {
        candidates.push(group[i])
      }
    }
  }

  return candidates
}

async function sendReapBatch(batch: bigint[]): Promise<void> {
  if (batch.length === 0) return

  if (cfg.dryRun) {
    console.log(`[DRY RUN] would reap ${batch.length}: ${batch.join(',')}`)
    return
  }

  try {
    // Simulation catches wrong address/ABI/network/config before spending gas.
    const simulation = await publicClient.simulateContract({
      account,
      address: cfg.gameEngine,
      abi: gameEngineAbi,
      functionName: 'reap',
      args: [batch]
    })

    const gas = await publicClient.estimateContractGas({
      account,
      address: cfg.gameEngine,
      abi: gameEngineAbi,
      functionName: 'reap',
      args: [batch]
    })

    if (gas > cfg.maxGasPerTx && batch.length > 1) {
      const midpoint = Math.ceil(batch.length / 2)
      console.warn(`Gas estimate ${gas} > cap ${cfg.maxGasPerTx}; splitting ${batch.length} IDs.`)
      await sendReapBatch(batch.slice(0, midpoint))
      await sendReapBatch(batch.slice(midpoint))
      return
    }

    const hash = await walletClient.writeContract(simulation.request)
    console.log(`reap(${batch.length}) sent: ${hash}`)
    const receipt = await publicClient.waitForTransactionReceipt({ hash, confirmations: cfg.confirmations })
    if (receipt.status !== 'success') throw new Error(`Transaction reverted: ${hash}`)
    console.log(`confirmed block=${receipt.blockNumber} gasUsed=${receipt.gasUsed}`)
  } catch (err) {
    // State can change between scan and send (player rescue/consume/settlement).
    // reap itself is idempotent, but adaptive split prevents one unusual batch
    // from stopping the entire keeper.
    if (batch.length > 1) {
      const midpoint = Math.ceil(batch.length / 2)
      console.warn(`Batch failed; splitting ${batch.length} IDs.`, err)
      await sendReapBatch(batch.slice(0, midpoint))
      await sendReapBatch(batch.slice(midpoint))
      return
    }
    console.error(`Single-ID reap failed for #${batch[0]}; skipping this sweep.`, err)
  }
}

async function sweep(): Promise<void> {
  const status = await readStatus()
  const phaseName = phaseNames[status.phase] ?? `UNKNOWN(${status.phase})`
  console.log(`\n[${new Date().toISOString()}] phase=${phaseName} S=${status.supply} alive=${status.alive}`)

  if (status.gameStart === 0n) {
    console.log('Game has not started. No action.')
    return
  }
  if (status.settled || status.phase === 5) {
    console.log('Game settled. Keeper is idle.')
    return
  }
  if (status.supply === 0n) {
    console.log('S=0. No action.')
    return
  }

  const candidates = await findCandidates(status.supply)
  if (candidates.length === 0) {
    console.log('No unsettled logical deaths.')
    return
  }

  console.log(`Found ${candidates.length} reap candidate(s): ${candidates.join(',')}`)
  for (const batch of chunks(candidates, cfg.reapBatchSize)) {
    await sendReapBatch(batch)
  }

  const after = await readStatus()
  console.log(`After sweep: alive=${after.alive} phase=${phaseNames[after.phase] ?? after.phase} settled=${after.settled}`)
}

async function main() {
  const balance = await publicClient.getBalance({ address: account.address })
  console.log('Gluttons Reap Keeper v1.0')
  console.log(`Keeper: ${account.address}`)
  console.log(`Engine: ${cfg.gameEngine}`)
  console.log(`Chain: ${cfg.chainName} (${cfg.chainId})`)
  console.log(`Balance: ${formatEther(balance)} ${cfg.nativeSymbol}`)
  console.log(`Mode: ${cfg.dryRun ? 'DRY RUN' : 'LIVE'}`)

  do {
    try {
      await sweep()
    } catch (err) {
      console.error('Sweep failed; keeper will retry next interval.', err)
    }
    if (cfg.runOnce) break
    await sleep(cfg.sweepIntervalMs)
  } while (true)
}

main().catch(err => {
  console.error(err)
  process.exitCode = 1
})
